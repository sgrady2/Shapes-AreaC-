//This file should contain your struct definition for Circle, Triangle, 
//and Rectangle


typedef struct {
	double minX;
	double minY;
	double maxX;
	double maxY;
} Rectangle;

typedef struct {
	double originX;
	double originY;
	double radius;
}Circle;

typedef struct {
	double p1x;
	double p2x;
	double minY;
	double maxY;

} Triangle;
